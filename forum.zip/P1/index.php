<?php

echo "Attendez...";
echo "<script>setTimeout(\"location.href = 'http://Localhost/P1/accueil.php';\",2000);</script>";

?>